/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

/**
 *
 * @author cisco
 */
public class JugadorBaloncesto {
    private String balonColor;
    private String zapatosColor;
    private String pantalonetaColor;
    private String nombre;

    public JugadorBaloncesto(String balonColor, String zapatosColor, String pantalonetaColor, String nombre) {
        this.balonColor = balonColor;
        this.zapatosColor = zapatosColor;
        this.pantalonetaColor = pantalonetaColor;
        this.nombre = nombre;
    }

    public String getBalonColor() {
        return balonColor;
    }

    public void setBalonColor(String balonColor) {
        this.balonColor = balonColor;
    }

    public String getZapatosColor() {
        return zapatosColor;
    }

    public void setZapatosColor(String zapatosColor) {
        this.zapatosColor = zapatosColor;
    }

    public String getPantalonetaColor() {
        return pantalonetaColor;
    }

    public void setPantalonetaColor(String pantalonetaColor) {
        this.pantalonetaColor = pantalonetaColor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void correr() {
        System.out.println("El jugador " + nombre + " está corriendo");
    }

    public void saltar() {
        System.out.println("El jugador " + nombre + " está saltando");
    }

    public void lanzarBalon() {
        System.out.println("El jugador " + nombre + " está lanzando el balón");
    }
}
