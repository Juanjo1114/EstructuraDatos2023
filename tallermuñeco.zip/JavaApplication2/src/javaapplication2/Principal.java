
package javaapplication2;


public class Principal {
    public static void main(String[] args) {
        JugadorBaloncesto jugador = new JugadorBaloncesto("naranja", "morado", "verde", "Juan");

        System.out.println("El balon de " + jugador.getNombre() + " es de color " + jugador.getBalonColor());
        jugador.correr();
    }
}